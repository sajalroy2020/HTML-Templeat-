(function($) {	
	
    'use strict';
	
	/* jQuery Settings Table
	
		# Cache jQuery Selector
		# MixIt-up Animation tab calling
		# Simple tab manus
		# Auto active class adding with navigation when you visit a link.
		# Active Fixed Header by Adding Class
		# Get Body Content space following the header height
		# Dropdown submenu on hover in desktopand dropdown sub menu on click in mobile
		# Layer Slider Testimonial
		# Single Product Image Slide
		# Click Search Icon and Open Search Field
		# Scroll trgeted ID specially for One Page nav target scrolling
		# Scroll top by clicking arrow up
		# Fact Counter For Achivement Counting
		# Our Partner Logos Slider Auto
		# Testimonial slide Carousel
		# Three Block Slide Carousel
		# Four Block Slide Carousel
		# Four Block Slide No Gap Carousel
		# Single Text Carousel
		# Contact Form Validation
		# Elements Animation
		# Start When document is Scrollig, do
		# Date Counting
		# Bootstrap selectpiker
		# Range Slider
		# Single Accordean
		
	*/


    //Cache jQuery Selector
    var $window = $(window),
        $header = $('header'),
        $brand = $('.partner-slider'),
        $navigation = $('#navbarSupportedContent'),
        $dropdown = $('.dropdown-toggle'),
        $single_carusel = $('.single-carusel'),
        $three_item = $('.3block-carusel'),
        $four_item = $('.4block-carusel'),
        $four_item_nogap = $('.4block-carusel-nogap'),
        $single_carusel_text = $('.text-carusel'),
        $mix_tab = $('.mix-tab');





    // Our Partner Logos Slider Auto Carousel
    if ($brand.length) {
        $brand.owlCarousel({
            loop: true,
            margin: 30,
            nav: false,
            dots: false,
            smartSpeed: 500,
            autoplay: 4000,
            responsive: {
                0: {
                    items: 2
                },
                480: {
                    items: 3
                },
                600: {
                    items: 3
                },
                800: {
                    items: 4
                },
                1200: {
                    items: 6
                }
            }
        });
    }

    
    $('.owl-carousel').owlCarousel({
        loop:true,
        margin:10,
        nav:false,
        autoplay:true,
        dots : true,
        autoplayTimeout:5000,
        navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
        responsive:{
            0:{
                items:1
            },
            600:{
                items:1
            },
            1000:{
                items:1
            }
        }
    }); 

    $('#slide_1').owlCarousel({
        loop:true,
        margin:10,
        responsiveClass:true,
        responsive:{
            0:{
                items:1,
                nav:true
            },
            600:{
                items:3,
                nav:false
            },
            1000:{
                items:5,
                nav:true,
                loop:false
            }
        }
    })


    $("input , textarea").focus(function(){
        $(this).css("background-color", "white");
    });
    $("input, textarea").focusout(function(){
        $(this).css("background-color", "#8f1d26");
    });


    $(document).on("scroll", function(){
        if
      ($(document).scrollTop() > 500){
          $("#header").addClass("shrink");
        }
        else
        {
            $("#header").removeClass("shrink");
        }
    });



})(jQuery);
  
